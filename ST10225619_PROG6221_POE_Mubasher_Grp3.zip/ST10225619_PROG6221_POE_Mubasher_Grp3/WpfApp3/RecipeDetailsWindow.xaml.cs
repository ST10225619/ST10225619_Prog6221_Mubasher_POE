﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for RecipeDetailsWindow.xaml
    /// </summary>
    public partial class RecipeDetailsWindow : Window
    {
        private List<Recipe> recipeList;

        public RecipeDetailsWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            recipeList = recipes;
            comboBoxRecipeName.ItemsSource = recipeList.Select(r => r.Name);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = comboBoxRecipeName.SelectedItem.ToString();
            string ingredientName = textBoxIngredName.Text;
            int ingredientQty = Convert.ToInt32(textBoxIngredQty.Text);
            int ingredientCalories = Convert.ToInt32(textBoxIngredCalories.Text);
            string ingredientUnitMeasure = textBoxIngredMeasure.Text;
            string foodGroup = comboBoxRecipeName.SelectedItem.ToString();
            string steps = textBoxSteps.Text;

            // Create a new Ingredient object using the provided data
            Ingredient ingredient = new Ingredient()
            {
                Name = ingredientName,
                Quantity = ingredientQty,
                Calories = ingredientCalories,
                UnitOfMeasurement = ingredientUnitMeasure,
                FoodGroup = foodGroup,
                Steps = steps
            };

            // Find the recipe in the recipe list
            Recipe selectedRecipe = recipeList.FirstOrDefault(r => r.Name == recipeName);

            if (selectedRecipe != null)
            {
                // Add the ingredient to the recipe's ingredient list
                selectedRecipe.Ingredients.Add(ingredient);

                MessageBox.Show("Ingredient added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Selected recipe not found.", "Recipe Not Found", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            // Clear the input fields and reset the combo box selection
            textBoxIngredName.Clear();
            textBoxIngredQty.Clear();
            textBoxIngredMeasure.Clear();
            textBoxIngredCalories.Clear();
            textBoxIngredMeasure.Clear();
            textBoxSteps.Clear();
            comboBoxRecipeName.SelectedIndex = -1;
        }

        private void buttonViewRecipes_Click(object sender, RoutedEventArgs e)
        {
            RecipeListWindow recipeListWindow = new RecipeListWindow(recipeList);
            recipeListWindow.Show();
        }
        private void textBoxSteps_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Handle the event logic here
        }

    }

}
