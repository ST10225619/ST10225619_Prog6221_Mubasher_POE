﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp3
{
    public partial class RecipeListWindow : Window
{
    private List<Recipe> recipeList;

    public RecipeListWindow(List<Recipe> recipes)
    {
        InitializeComponent();
        recipeList = recipes;
        comboBoxViewRecipe.ItemsSource = recipeList.Select(r => r.Name);
    }

    private void viewRecipeButton_Click(object sender, RoutedEventArgs e)
    {
        // Get the selected recipe name from the ComboBox
        string selectedRecipeName = comboBoxViewRecipe.SelectedItem.ToString();

        // Find the selected recipe from the recipeList
        Recipe selectedRecipe = recipeList.FirstOrDefault(r => r.Name == selectedRecipeName);

        if (selectedRecipe != null)
        {
            StringBuilder recipeDetails = new StringBuilder();
            recipeDetails.AppendLine($"Recipe Name: {selectedRecipe.Name}");
            recipeDetails.AppendLine("Ingredients:");

            foreach (Ingredient ingredient in selectedRecipe.Ingredients)
            {
                recipeDetails.AppendLine($"- Ingredient Name: {ingredient.Name}");
                recipeDetails.AppendLine($"  Quantity: {ingredient.Quantity}");
                recipeDetails.AppendLine($"  Calories: {ingredient.Calories}");
                recipeDetails.AppendLine($"  Unit of Measurement: {ingredient.UnitOfMeasurement}");
                recipeDetails.AppendLine($"  Food Group: {ingredient.FoodGroup}");
                recipeDetails.AppendLine($"  Steps: {ingredient.Steps}");
            }

            // Set the recipe details to the TextBlock
            viewDetailsTextBlock.Text = recipeDetails.ToString();
        }
        else
        {
            // Display a message if the selected recipe is not found
            MessageBox.Show("Selected recipe not found.", "Recipe Not Found", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}

}
