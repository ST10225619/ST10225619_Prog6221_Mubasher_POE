﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipeList;

        public MainWindow()
        {
            InitializeComponent();
            recipeList = new List<Recipe>();
        }

        private void buttonSaveName_Click(object sender, RoutedEventArgs e)
        {
            SaveRecipeName();
        }

        private void SaveRecipeName()
        {
            string recipeName = textBoxRecipeName.Text;
            if (!string.IsNullOrEmpty(recipeName))
            {
                // Create a new Recipe object and add it to the recipeList
                Recipe recipe = new Recipe { Name = recipeName };
                recipeList.Add(recipe);
                recipeList.Sort((r1, r2) => r1.Name.CompareTo(r2.Name));

                // Clear the text box after saving the recipe name
                textBoxRecipeName.Clear();
            }
            else
            {
                MessageBox.Show("Recipe Name Must Not Be Blank", "Null Entry", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void buttonAddDetails_Click(object sender, RoutedEventArgs e)
        {
            RecipeDetailsWindow recipeDetailsWindow = new RecipeDetailsWindow(recipeList);

            this.Close();
            recipeDetailsWindow.Show();
        }
    }
}
