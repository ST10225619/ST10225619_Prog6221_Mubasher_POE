﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3
{
   public class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }

    public Recipe()
    {
        Ingredients = new List<Ingredient>();
    }
}

public class Ingredient
{
    public string Name { get; set; }
    public int Quantity { get; set; }
    public int Calories { get; set; }
    public string UnitOfMeasurement { get; set; }
    public string FoodGroup { get; set; }

    public string Steps { get; set; }

}
}
